using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Vars
{
}

public class EntityInfo
{
    int entityID = -1;
    Vector3 position = Vector3.zero;
    Vector3 rotation = Vector3.zero;
}

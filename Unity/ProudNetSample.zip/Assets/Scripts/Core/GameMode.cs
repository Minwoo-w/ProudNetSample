using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameMode : MonoBehaviour
{
    // Singleton
    private static GameMode instance;
    public static GameMode Instance { get { return instance; } }

    [SerializeField] private CharacterSO characterSO = null;
    private Actor selfActor = null;
    private List<Actor> actors = new List<Actor>();

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;

#if UNITY_STANDALONE
            Screen.SetResolution(800, 640, false, 30);
#elif UNITY_WEBGL
            Application.targetFrameRate = 30;
#endif
            
            //selfActor = CreateActor("Player");
            //selfActor.SetIsMine(true);
        }
        else
        {
            Destroy(instance);
        }
    }

    private Actor tempActor = null;
    public Actor CreateActor(string name)
    {
        tempActor = characterSO.GetActorPrefab(name);
        if (tempActor != null)
        {
            // Instansing
            tempActor = Instantiate(tempActor);
            actors.Add(tempActor);
        }
        return tempActor;
    }

    public void DestroyActor(int id)
    {
        Actor actor = null;
        for (int i = 0; i < actors.Count; i++)
        {
            if (actors[i].id == id)
            {
                actor = actors[i];
                actors.RemoveAt(i);
                break;
            }
        }

        if (actor != null)
        {
            Destroy(actor.gameObject);
        }
    }

    public Actor GetActorByID(int id)
    {
        tempActor = null;
        for (int i = 0; i < actors.Count; i++)
        {
            if (actors[i].id == id)
            {
                tempActor = actors[i];
                break;
            }
        }
        return tempActor;
    }

    public int GetActorCount()
    {
        return actors.Count;
    }

    //private Actor FindActorByHostID(int hostId)
    //{
    //    Actor result = null;
    //    for (int i = 0; i < actors.Count; i++)
    //    {
    //        if (actors[i].id == hostId)
    //        {
    //            result = actors[i];
    //            break;
    //        }
    //    }

    //    return result;
    //}

    //private Actor FindOrCreateActorByHostID(int hostId)
    //{
    //    Actor result = FindActorByHostID(hostId);
    //    if (result == null)
    //    {
    //        result = CreateActor(hostId);
    //    }

    //    return result;
    //}

    //private Actor CreateActor(int hostId)
    //{
    //    Actor instance = Instantiate(characterSO.GetActorPrefab(""));
    //    instance.id = hostId;
    //    actors.Add(instance);
    //    return instance;
    //}

    //private bool DestroyActor(int hostId)
    //{
    //    Actor actor = FindActorByHostID(hostId);
    //    if (actor != null)
    //    {
    //        Destroy(actor);
    //    }
    //    return true;
    //}
}
